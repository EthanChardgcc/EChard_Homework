/**
 * Class: MethodPractice.java
 * @author Ethan Chard
 * Version: 1.0
 * Course: ITEC 2150 Fall 2023
 * Written: August 19, 2023
 * This class assigns the value of 4 to x. Then in the next line the formula of square is created
 * by multiplying x by x. Lastly it prints out the square of x to the console.
 *
 */
public class MethodPractice 
{
	static void calculateSquare()
	{
		int x = 4;
		int CalculateSquare = x * x;
		System.out.println("The square of x is " + CalculateSquare);
	}
	public static void main(String[] args)
	{
		calculateSquare();
	
		
	}
}
