/**
 * Class: Variable.java
 * @author Ethan Chard
 * Version: 1.0
 * Course: ITEC 2150 Fall 2023
 * Written: August 19, 2023
 *This class assigns the integer to the name temperature and prints out the integer. 
 *Then the second part it assigns a first and last name. After the fist and last name is assigned it prints out both together.
 *
 */
public class VariablePractice 
{
	public static void main(String[] args) 
	{
		int temperature = 25;
		System.out.println(temperature);
		String firstName = "Ethan";
		String lastName = "Chard";
		System.out.println(firstName + " " + lastName);
	}
}
